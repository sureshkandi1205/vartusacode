package com.virtusa.parser.constant;

public enum ParserEnum {

	CSV_SEPARATOR(',', '"'); // calls constructor with CSV separator and quote

	private final char separator;
	private final char quote;

	ParserEnum(char separator, char quote) {
		this.separator = separator;
		this.quote = quote;
	}

	public char getSeparator() {
		return this.separator;
	}

	public char getQuote() {
		return this.quote;
	}

}
