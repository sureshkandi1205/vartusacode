package com.virtusa.parser;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import com.virtusa.parser.exception.ParserException;

public interface Parser {

	List<List<String>> parseFile(String filePath,Boolean skipHeader) throws FileNotFoundException, ParserException,IOException;

}
