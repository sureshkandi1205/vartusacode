package com.virtusa.parser.exception;

public class ParserException extends RuntimeException {

	private static final long serialVersionUID = 3426768063308956519L;

	public ParserException(String message) {
		super(message);
	}

}
