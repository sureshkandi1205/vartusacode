package com.virtusa.parser;

import java.io.File;
import java.util.List;

public class ParserTest {

	public static void main(String[] args) throws Exception {
		String csvFile = "resources"+File.separator+"employee.csv";
		Parser parser = new CSVParser();
		List<List<String>> output = parser.parseFile(csvFile,Boolean.TRUE);
		System.out.println(output);
	}
}
