package com.virtusa.numbertoword;

public class ConverterTest {

	public static void main(String[] args) {
		NumberToWordConverter obj = new NumberToWordConverter();
		System.out.println("*** " + obj.convert(123456789));
		System.out.println("*** " + obj.convert(-55));
	}

}
